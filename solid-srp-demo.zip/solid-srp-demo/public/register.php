<?php

declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';

use App\Application\UserService;
use App\Domain\UserValidator;
use App\Infra\FileUserRepository;

$file = __DIR__ . '/../storage/user.txt';

$service = new UserService(new FileUserRepository($file), new UserValidator);

$testUser = [
    [
    'name' => "João",
    'email' => "joao@unimar.br",
    'password' => "Teste123"
    ],
    [
    'name' => "Maria",
    'email' => "maria@unimar.br",
    'password' => "Teste123"
    ],
    [
    'name' => "Pedro",
    'email' => "pedro@unimar.br",
    'password' => "Teste123"
    ],
    [
    'name' => "Ana",
    'email' => "ana@unimar.br",
    'password' => "Teste123"
    ],
    [
    'name' => "Lucas",
    'email' => "lucas@unimar.br",
    'password' => "Teste123"
    ]
];

$response = $service->register($testUser);
$httpCode = $response ? 201 : 422;

http_response_code($httpCode);

echo $response ? 'Usuário cadastrado com sucesso' : 'Falha no cadastro';