<?php

declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';

use App\Application\ListUserService;
use App\Domain\UserValidator;
use App\Infra\FileUserRepository;

$file = __DIR__ . '/../storage/user.txt';

$service = new ListUserService(new FileUserRepository($file), new UserValidator);

$users = $service->findAll();

echo json_encode($users);


?>

