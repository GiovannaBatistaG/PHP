<?php

declare(strict_types=1);

namespace App\Application;

use App\Domain\UserRepository;
use App\Domain\UserValidator;

class ListUserService
{
  private UserRepository $repository;
  private UserValidator $validator;

  public function __construct(UserRepository $repository, UserValidator $validator)
  {
    $this->repository = $repository;
    $this->validator = $validator;
  }

  /**
     * @param array{name?:string,email?:string,password?:string} $input
     */
    public function findAll(): array
    {
      return $this->repository->findAll();
    }


}


?>